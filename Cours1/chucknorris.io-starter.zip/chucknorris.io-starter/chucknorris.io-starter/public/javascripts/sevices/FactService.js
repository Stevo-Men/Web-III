import { FACTS } from "../mocks/facts.js"

export default class FactService {
    searchMockFacts(query) {
        const filteredResults = [];
    for (const fact of FACTS) {
       if (fact.value.includes(query)) {
        filteredResults.push(fact);
       }
    }
    return filteredResults;
    }

    searchFacts(query) {
        
    }
}