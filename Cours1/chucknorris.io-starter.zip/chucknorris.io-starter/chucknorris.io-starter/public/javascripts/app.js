import { FACTS } from "./mocks/facts.js";
import FactService from "./sevices/FactService.js";
import FactTemplate from "./templates/FactTemplate.js";

const searchInputField = document.querySelector("[data-search-facts]");
const container = document.querySelector("[data-facts]");

const factService = new FactService();


searchInputField.addEventListener("keyup", (event) => {
    const query = event.target.value;
    if (!query || query.length < 3) {
        return;
    }
  

    //const results = factService.searchFacts(query);

    const url = `https://api.chucknorris.io/jokes/search?query={query}`

    fetch(url).then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then((jsonResult) => {
            container.innerHTML = FactTemplate.facts(jsonResult);
        });

    //    const response = await fetch(url);
    //    if (!response.ok) {
    //     throw new Error("Error")
    //    }


    //    const json = await response.json();
    //    container.innerHTML = FactTemplate.facts(json.jsonResult)
});
